Development files only.

easyrsa-windows-conf: EasyRSA make configuration file.

Use with:
https://github.com/rmyorston/busybox-w32

Build with Fedora.

busybox.exe: Windows executable.

